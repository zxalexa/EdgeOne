import { Navbar } from "@/components/sections/navbar";
import { Hero } from "@/components/sections/hero";
import { About } from "@/components/sections/about";
import { Services } from "@/components/sections/services";
import { Process } from "@/components/sections/process";
import { Work } from "@/components/sections/work";
import { TechStack } from "@/components/sections/tech-stack";
import { CTA } from "@/components/sections/cta";
import { Footer } from "@/components/sections/footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-[#141414]">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Process />
      <Work />
      <TechStack />
      <CTA />
      <Footer />
    </main>
  );
}
