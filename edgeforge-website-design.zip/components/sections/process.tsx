"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const processSteps = [
  {
    id: "01",
    title: "Discover",
    description:
      "Deep dive into your security landscape, identifying vulnerabilities and opportunities.",
  },
  {
    id: "02",
    title: "Design",
    description:
      "Architecture blueprints with security woven into every layer from the ground up.",
  },
  {
    id: "03",
    title: "Build",
    description:
      "Rapid development cycles with continuous security testing and validation.",
  },
  {
    id: "04",
    title: "Secure",
    description:
      "Penetration testing, audits, and hardening before any code reaches production.",
  },
  {
    id: "05",
    title: "Launch",
    description:
      "Monitored deployment with 24/7 threat detection and incident response.",
  },
];

export function Process() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  return (
    <section id="process" className="relative bg-[#141414] py-24 lg:py-40">
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      <div ref={ref}>
        {/* Section header */}
        <div className="mb-12 px-6 lg:mb-16 lg:px-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-4 block font-mono text-xs uppercase tracking-[0.2em] text-[#ff6b2c]"
          >
            03 / Process
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="max-w-2xl font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase leading-tight text-[#f4e7d3] lg:text-5xl"
          >
            How We <span className="text-[#5eead4]">Work</span>
          </motion.h2>
        </div>

        {/* Horizontal scroll timeline */}
        <div className="relative">
          {/* Timeline line */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={isInView ? { scaleX: 1 } : {}}
            transition={{ duration: 1.5, delay: 0.3 }}
            className="absolute left-0 right-0 top-1/2 hidden h-px origin-left -translate-y-1/2 bg-[#f4e7d3]/10 lg:block"
          />

          {/* Scrollable container */}
          <div
            ref={scrollContainerRef}
            className="horizontal-scroll overflow-x-auto pb-8"
          >
            <div className="flex gap-6 px-6 lg:gap-0 lg:px-16">
              {processSteps.map((step, index) => (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, y: 40 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.15 }}
                  className="group relative min-w-[280px] flex-shrink-0 lg:min-w-0 lg:flex-1 lg:px-8"
                >
                  {/* Step number dot */}
                  <div className="relative mb-8 hidden lg:block">
                    <div className="mx-auto flex h-16 w-16 items-center justify-center">
                      <motion.div
                        whileHover={{ scale: 1.2 }}
                        className="relative flex h-4 w-4 items-center justify-center"
                      >
                        <div className="absolute h-4 w-4 rounded-full border border-[#ff6b2c] transition-all duration-300 group-hover:scale-150 group-hover:border-[#5eead4]" />
                        <div className="h-2 w-2 rounded-full bg-[#ff6b2c] transition-colors duration-300 group-hover:bg-[#5eead4]" />
                      </motion.div>
                    </div>
                  </div>

                  {/* Card */}
                  <div className="glass-card relative h-full overflow-hidden p-6 transition-all duration-500 hover:border-[#ff6b2c]/30">
                    {/* Background number */}
                    <span className="absolute -bottom-4 -right-2 font-[family-name:var(--font-space-grotesk)] text-8xl font-bold text-[#f4e7d3]/3">
                      {step.id}
                    </span>

                    {/* Mobile step indicator */}
                    <div className="mb-4 flex items-center gap-3 lg:hidden">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full border border-[#ff6b2c]">
                        <span className="font-mono text-xs text-[#ff6b2c]">
                          {step.id}
                        </span>
                      </div>
                      {index < processSteps.length - 1 && (
                        <div className="h-px flex-1 bg-[#f4e7d3]/10" />
                      )}
                    </div>

                    <h3 className="mb-3 font-[family-name:var(--font-space-grotesk)] text-xl font-bold uppercase text-[#f4e7d3] transition-colors duration-300 group-hover:text-[#ff6b2c]">
                      {step.title}
                    </h3>
                    <p className="relative z-10 text-sm leading-relaxed text-[#f4e7d3]/60">
                      {step.description}
                    </p>

                    {/* Arrow connector (desktop only) */}
                    {index < processSteps.length - 1 && (
                      <div className="absolute -right-4 top-1/2 hidden -translate-y-1/2 text-[#5eead4]/30 lg:block">
                        <svg
                          className="h-6 w-6"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={1}
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Scroll hint (mobile) */}
          <div className="flex justify-center lg:hidden">
            <motion.div
              animate={{ x: [0, 10, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="flex items-center gap-2 text-[#f4e7d3]/40"
            >
              <span className="font-mono text-[10px] uppercase tracking-widest">
                Scroll
              </span>
              <svg
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
