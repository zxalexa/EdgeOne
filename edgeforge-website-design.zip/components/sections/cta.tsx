"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

export function CTA() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      id="contact"
      className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#141414] py-24 lg:py-40"
    >
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      {/* Background gradient mesh */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 0.3 } : {}}
          transition={{ duration: 1.5 }}
          className="mesh-animate absolute -left-1/4 top-1/4 h-[600px] w-[600px] rounded-full bg-[#ff6b2c] blur-[150px]"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 0.2 } : {}}
          transition={{ duration: 1.5, delay: 0.3 }}
          className="mesh-animate absolute -right-1/4 bottom-1/4 h-[500px] w-[500px] rounded-full bg-[#5eead4] blur-[150px]"
        />
      </div>

      <div ref={ref} className="relative z-10 px-6 text-center lg:px-16">
        {/* Section label */}
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-8 block font-mono text-xs uppercase tracking-[0.3em] text-[#ff6b2c]"
        >
          Start a Project
        </motion.span>

        {/* Giant typography */}
        <motion.h2
          initial={{ opacity: 0, y: 60 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.2 }}
          className="mb-8 font-[family-name:var(--font-space-grotesk)] text-4xl font-bold uppercase leading-[0.95] tracking-tight text-[#f4e7d3] sm:text-6xl lg:text-8xl xl:text-9xl"
        >
          Build
          <br />
          <span className="text-glow-cyan text-[#5eead4]">something</span>
          <br />
          unbreakable.
        </motion.h2>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mx-auto mb-12 max-w-md text-base leading-relaxed text-[#f4e7d3]/60 lg:text-lg"
        >
          Ready to fortify your digital presence? Let&apos;s engineer solutions
          that stand the test of time.
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="flex flex-col items-center justify-center gap-4 sm:flex-row"
        >
          <a
            href="mailto:hello@edgeforge.io"
            className="glow-orange group inline-flex items-center gap-3 bg-[#ff6b2c] px-8 py-4 font-mono text-sm uppercase tracking-wider text-[#141414] transition-all hover:bg-[#ff8c5a]"
          >
            <span>Get in Touch</span>
            <svg
              className="h-5 w-5 transition-transform group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </a>
          <a
            href="#"
            className="inline-flex items-center gap-2 border border-[#f4e7d3]/20 px-8 py-4 font-mono text-sm uppercase tracking-wider text-[#f4e7d3] transition-all hover:border-[#f4e7d3]/40 hover:bg-[#f4e7d3]/5"
          >
            Schedule Call
          </a>
        </motion.div>

        {/* Email hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-16"
        >
          <span className="font-mono text-xs uppercase tracking-widest text-[#f4e7d3]/30">
            hello@edgeforge.io
          </span>
        </motion.div>
      </div>
    </section>
  );
}
