"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const technologies = [
  { name: "React", category: "Frontend" },
  { name: "Next.js", category: "Framework" },
  { name: "TypeScript", category: "Language" },
  { name: "Node.js", category: "Runtime" },
  { name: "PostgreSQL", category: "Database" },
  { name: "Redis", category: "Cache" },
  { name: "AWS", category: "Cloud" },
  { name: "Docker", category: "Container" },
  { name: "Kubernetes", category: "Orchestration" },
  { name: "Terraform", category: "IaC" },
  { name: "GraphQL", category: "API" },
  { name: "Python", category: "Language" },
];

export function TechStack() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="tech" className="relative bg-[#141414] py-24 lg:py-40">
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      <div ref={ref} className="px-6 lg:px-16">
        {/* Section header - centered */}
        <div className="mb-16 text-center lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-4 block font-mono text-xs uppercase tracking-[0.2em] text-[#ff6b2c]"
          >
            05 / Tech Stack
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase leading-tight text-[#f4e7d3] lg:text-5xl"
          >
            Our <span className="text-[#5eead4]">Arsenal</span>
          </motion.h2>
        </div>

        {/* Tech grid - minimal logo style */}
        <div className="mx-auto max-w-5xl">
          <div className="grid grid-cols-3 gap-4 sm:grid-cols-4 md:grid-cols-6 lg:gap-6">
            {technologies.map((tech, index) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{
                  duration: 0.4,
                  delay: 0.1 + index * 0.05,
                }}
                className="group"
              >
                <div className="glass-card flex aspect-square flex-col items-center justify-center p-4 transition-all duration-300 hover:border-[#ff6b2c]/30">
                  {/* Tech name as minimal "logo" */}
                  <span className="font-[family-name:var(--font-space-grotesk)] text-sm font-bold uppercase tracking-tight text-[#f4e7d3]/80 transition-colors duration-300 group-hover:text-[#ff6b2c] lg:text-base">
                    {tech.name}
                  </span>
                  {/* Category */}
                  <span className="mt-1 font-mono text-[8px] uppercase tracking-widest text-[#f4e7d3]/30 transition-colors duration-300 group-hover:text-[#5eead4] lg:text-[9px]">
                    {tech.category}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Additional text */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mx-auto mt-16 max-w-2xl text-center text-sm leading-relaxed text-[#f4e7d3]/50"
        >
          We leverage cutting-edge technologies to build secure, scalable
          solutions. Our stack evolves with the industry, ensuring your systems
          stay ahead of threats.
        </motion.p>
      </div>
    </section>
  );
}
