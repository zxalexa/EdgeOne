"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const footerLinks = [
  {
    title: "Services",
    links: [
      { name: "Edge Security", href: "#" },
      { name: "AI Systems", href: "#" },
      { name: "Cloud Infrastructure", href: "#" },
      { name: "App Development", href: "#" },
    ],
  },
  {
    title: "Company",
    links: [
      { name: "About", href: "#about" },
      { name: "Process", href: "#process" },
      { name: "Work", href: "#work" },
      { name: "Contact", href: "#contact" },
    ],
  },
  {
    title: "Connect",
    links: [
      { name: "Twitter", href: "#" },
      { name: "LinkedIn", href: "#" },
      { name: "GitHub", href: "#" },
      { name: "Dribbble", href: "#" },
    ],
  },
];

export function Footer() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <footer className="relative bg-[#141414]">
      {/* Top divider line */}
      <div className="section-divider" />

      <div ref={ref} className="px-6 py-16 lg:px-16 lg:py-24">
        {/* Main footer content */}
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-8">
          {/* Logo and tagline */}
          <div className="lg:col-span-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
            >
              {/* Logo */}
              <div className="mb-6 flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center bg-[#ff6b2c]">
                  <span className="font-[family-name:var(--font-space-grotesk)] text-sm font-bold text-[#141414]">
                    E
                  </span>
                </div>
                <span className="font-[family-name:var(--font-space-grotesk)] text-lg font-bold uppercase tracking-tight text-[#f4e7d3]">
                  EDGEFORGE
                </span>
              </div>

              <p className="max-w-xs text-sm leading-relaxed text-[#f4e7d3]/50">
                Engineering security at the edge of innovation. We build
                unbreakable digital systems.
              </p>

              {/* Status indicator */}
              <div className="mt-6 flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#5eead4] opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-[#5eead4]" />
                </span>
                <span className="font-mono text-[10px] uppercase tracking-widest text-[#5eead4]">
                  All Systems Operational
                </span>
              </div>
            </motion.div>
          </div>

          {/* Links */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-6 lg:col-start-7">
            {footerLinks.map((group, groupIndex) => (
              <motion.div
                key={group.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.1 + groupIndex * 0.1 }}
              >
                <h4 className="mb-4 font-mono text-[10px] uppercase tracking-[0.2em] text-[#f4e7d3]/40">
                  {group.title}
                </h4>
                <ul className="space-y-3">
                  {group.links.map((link) => (
                    <li key={link.name}>
                      <a
                        href={link.href}
                        className="text-sm text-[#f4e7d3]/70 transition-colors hover:text-[#ff6b2c]"
                      >
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-[#f4e7d3]/10 pt-8 lg:mt-24 lg:flex-row"
        >
          <span className="font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/30">
            © 2026 EDGEFORGE. All rights reserved.
          </span>

          <div className="flex items-center gap-6">
            <a
              href="#"
              className="font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/30 transition-colors hover:text-[#f4e7d3]/60"
            >
              Privacy
            </a>
            <a
              href="#"
              className="font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/30 transition-colors hover:text-[#f4e7d3]/60"
            >
              Terms
            </a>
            <a
              href="#"
              className="font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/30 transition-colors hover:text-[#f4e7d3]/60"
            >
              Security
            </a>
          </div>
        </motion.div>
      </div>

      {/* Large background text */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 overflow-hidden">
        <span className="block translate-y-1/3 text-center font-[family-name:var(--font-space-grotesk)] text-[15vw] font-bold uppercase leading-none text-[#f4e7d3]/[0.02]">
          EDGEFORGE
        </span>
      </div>
    </footer>
  );
}
