"use client";

import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";

const projects = [
  {
    id: 1,
    title: "NexusVault",
    category: "Enterprise Security",
    description: "Zero-trust authentication platform for Fortune 500 companies",
    tags: ["Security", "Enterprise", "Auth"],
    size: "large",
  },
  {
    id: 2,
    title: "SentinelAI",
    category: "AI Systems",
    description: "Real-time threat detection powered by machine learning",
    tags: ["AI", "Security", "Monitoring"],
    size: "medium",
  },
  {
    id: 3,
    title: "CloudFortress",
    category: "Infrastructure",
    description: "Multi-cloud security orchestration platform",
    tags: ["Cloud", "DevOps", "AWS"],
    size: "medium",
  },
  {
    id: 4,
    title: "EdgeGuard",
    category: "Edge Computing",
    description: "Distributed security layer for IoT networks",
    tags: ["Edge", "IoT", "Network"],
    size: "small",
  },
  {
    id: 5,
    title: "CipherFlow",
    category: "Data Security",
    description: "End-to-end encrypted data pipeline system",
    tags: ["Encryption", "Data", "Pipeline"],
    size: "small",
  },
  {
    id: 6,
    title: "AutoSecure",
    category: "Automation",
    description: "Automated compliance and security audit workflows",
    tags: ["Automation", "Compliance", "Audit"],
    size: "large",
  },
];

function ProjectCard({ project, index }: { project: (typeof projects)[0]; index: number }) {
  const [isHovered, setIsHovered] = useState(false);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  // Masonry-style varying heights
  const heightClasses = {
    large: "row-span-2 min-h-[400px] lg:min-h-[500px]",
    medium: "row-span-1 min-h-[280px] lg:min-h-[320px]",
    small: "row-span-1 min-h-[240px] lg:min-h-[280px]",
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.1 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`group relative overflow-hidden ${heightClasses[project.size as keyof typeof heightClasses]}`}
    >
      {/* Glass card background */}
      <div className="glass-card absolute inset-0 transition-all duration-500 group-hover:border-[#ff6b2c]/40" />

      {/* Background gradient on hover */}
      <motion.div
        initial={false}
        animate={{
          opacity: isHovered ? 0.15 : 0,
        }}
        className="absolute inset-0 bg-gradient-to-br from-[#ff6b2c] via-transparent to-[#5eead4]"
      />

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col justify-between p-6 lg:p-8">
        {/* Top section */}
        <div>
          {/* Category tag */}
          <motion.span
            initial={false}
            animate={{ y: isHovered ? 0 : -10, opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.3 }}
            className="mb-3 inline-block font-mono text-[10px] uppercase tracking-widest text-[#5eead4]"
          >
            {project.category}
          </motion.span>

          {/* Project number */}
          <span className="absolute right-6 top-6 font-[family-name:var(--font-space-grotesk)] text-6xl font-bold text-[#f4e7d3]/5 transition-colors duration-500 group-hover:text-[#ff6b2c]/10 lg:text-8xl">
            {String(project.id).padStart(2, "0")}
          </span>
        </div>

        {/* Bottom section */}
        <div>
          {/* Title */}
          <h3 className="mb-3 font-[family-name:var(--font-space-grotesk)] text-2xl font-bold uppercase text-[#f4e7d3] transition-colors duration-300 group-hover:text-[#ff6b2c] lg:text-3xl">
            {project.title}
          </h3>

          {/* Description - reveals on hover */}
          <motion.p
            initial={false}
            animate={{
              opacity: isHovered ? 1 : 0,
              y: isHovered ? 0 : 10,
            }}
            transition={{ duration: 0.3 }}
            className="mb-4 max-w-xs text-sm leading-relaxed text-[#f4e7d3]/70"
          >
            {project.description}
          </motion.p>

          {/* Tags */}
          <motion.div
            initial={false}
            animate={{
              opacity: isHovered ? 1 : 0.5,
              y: isHovered ? 0 : 5,
            }}
            transition={{ duration: 0.3 }}
            className="flex flex-wrap gap-2"
          >
            {project.tags.map((tag) => (
              <span
                key={tag}
                className="border border-[#f4e7d3]/10 px-2 py-1 font-mono text-[9px] uppercase tracking-wider text-[#f4e7d3]/50 transition-colors duration-300 group-hover:border-[#5eead4]/30 group-hover:text-[#5eead4]"
              >
                {tag}
              </span>
            ))}
          </motion.div>

          {/* View project link */}
          <motion.div
            initial={false}
            animate={{
              opacity: isHovered ? 1 : 0,
              x: isHovered ? 0 : -10,
            }}
            transition={{ duration: 0.3 }}
            className="mt-6 flex items-center gap-2 text-[#ff6b2c]"
          >
            <span className="font-mono text-xs uppercase tracking-wider">
              View Project
            </span>
            <svg
              className="h-4 w-4 transition-transform group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </motion.div>
        </div>
      </div>

      {/* Corner accent */}
      <div className="absolute bottom-0 right-0 h-12 w-12 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className="absolute bottom-0 right-0 h-full w-px bg-gradient-to-t from-[#ff6b2c] to-transparent" />
        <div className="absolute bottom-0 right-0 h-px w-full bg-gradient-to-l from-[#ff6b2c] to-transparent" />
      </div>
    </motion.div>
  );
}

export function Work() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="work" className="relative bg-[#141414] py-24 lg:py-40">
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      <div ref={ref} className="px-6 lg:px-16">
        {/* Section header */}
        <div className="mb-16 flex flex-col justify-between gap-8 lg:mb-24 lg:flex-row lg:items-end">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6 }}
              className="mb-4 block font-mono text-xs uppercase tracking-[0.2em] text-[#ff6b2c]"
            >
              04 / Featured Work
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="max-w-xl font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase leading-tight text-[#f4e7d3] lg:text-5xl"
            >
              Selected <span className="text-[#5eead4]">Projects</span>
            </motion.h2>
          </div>

          <motion.a
            href="#"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="group inline-flex items-center gap-2 self-start font-mono text-sm uppercase tracking-wider text-[#f4e7d3]/70 transition-colors hover:text-[#ff6b2c]"
          >
            View All Projects
            <svg
              className="h-4 w-4 transition-transform group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </motion.a>
        </div>

        {/* Masonry grid */}
        <div className="grid auto-rows-auto gap-6 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
