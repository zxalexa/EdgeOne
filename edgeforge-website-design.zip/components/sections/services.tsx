"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const services = [
  {
    id: "01",
    title: "Edge Security",
    description:
      "Perimeter defense and zero-trust architecture for distributed systems. Real-time threat detection at the network edge.",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        className="h-6 w-6"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1.5}
          d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
        />
      </svg>
    ),
  },
  {
    id: "02",
    title: "AI Web Systems",
    description:
      "Intelligent web applications powered by machine learning. Adaptive interfaces that learn and evolve.",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        className="h-6 w-6"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1.5}
          d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
        />
      </svg>
    ),
  },
  {
    id: "03",
    title: "Cloud Infrastructure",
    description:
      "Scalable, secure cloud architectures built for performance. Multi-cloud strategies with encrypted data flows.",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        className="h-6 w-6"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1.5}
          d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z"
        />
      </svg>
    ),
  },
  {
    id: "04",
    title: "App Development",
    description:
      "Native and cross-platform applications with security-first design. From concept to deployment, fully protected.",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        className="h-6 w-6"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1.5}
          d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
        />
      </svg>
    ),
  },
  {
    id: "05",
    title: "Automation",
    description:
      "Intelligent workflow automation and DevSecOps pipelines. Continuous security integration from day one.",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        className="h-6 w-6"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1.5}
          d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
        />
      </svg>
    ),
  },
];

function ServiceCard({
  service,
  index,
}: {
  service: (typeof services)[0];
  index: number;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  // Staggered diagonal positioning
  const offsetClasses = [
    "lg:translate-y-0",
    "lg:translate-y-16",
    "lg:translate-y-8",
    "lg:translate-y-24",
    "lg:translate-y-4",
  ];

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: index * 0.15 }}
      className={`group ${offsetClasses[index]}`}
    >
      <div className="glass-card relative overflow-hidden p-6 transition-all duration-500 hover:border-[#ff6b2c]/30 lg:p-8">
        {/* Hover glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#ff6b2c]/0 to-[#5eead4]/0 opacity-0 transition-opacity duration-500 group-hover:opacity-10" />

        {/* Service number */}
        <span className="absolute right-4 top-4 font-[family-name:var(--font-space-grotesk)] text-5xl font-bold text-[#f4e7d3]/5 transition-colors duration-300 group-hover:text-[#ff6b2c]/10 lg:text-6xl">
          {service.id}
        </span>

        {/* Icon */}
        <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-sm border border-[#f4e7d3]/10 text-[#5eead4] transition-all duration-300 group-hover:border-[#ff6b2c]/30 group-hover:text-[#ff6b2c]">
          {service.icon}
        </div>

        {/* Content */}
        <h3 className="mb-3 font-[family-name:var(--font-space-grotesk)] text-xl font-bold uppercase text-[#f4e7d3] lg:text-2xl">
          {service.title}
        </h3>
        <p className="text-sm leading-relaxed text-[#f4e7d3]/60 lg:text-base">
          {service.description}
        </p>

        {/* Arrow */}
        <div className="mt-6 flex items-center gap-2 text-[#ff6b2c] opacity-0 transition-all duration-300 group-hover:opacity-100">
          <span className="font-mono text-xs uppercase tracking-wider">
            Learn More
          </span>
          <svg
            className="h-4 w-4 transition-transform group-hover:translate-x-1"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M17 8l4 4m0 0l-4 4m4-4H3"
            />
          </svg>
        </div>
      </div>
    </motion.div>
  );
}

export function Services() {
  const titleRef = useRef(null);
  const isTitleInView = useInView(titleRef, { once: true, margin: "-100px" });

  return (
    <section id="services" className="relative bg-[#141414] py-24 lg:py-40">
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      <div className="px-6 lg:px-16">
        {/* Section header */}
        <div ref={titleRef} className="mb-16 lg:mb-24">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={isTitleInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="mb-4 block font-mono text-xs uppercase tracking-[0.2em] text-[#ff6b2c]"
          >
            02 / Services
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            animate={isTitleInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="max-w-2xl font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase leading-tight text-[#f4e7d3] lg:text-5xl"
          >
            What We <span className="text-[#5eead4]">Build</span>
          </motion.h2>
        </div>

        {/* Services grid - diagonal/staggered layout */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {services.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
