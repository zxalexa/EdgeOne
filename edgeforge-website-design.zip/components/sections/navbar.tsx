"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useState, useEffect } from "react";

const navLinks = [
  { name: "About", href: "#about" },
  { name: "Services", href: "#services" },
  { name: "Work", href: "#work" },
  { name: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const { scrollY } = useScroll();
  const opacity = useTransform(scrollY, [0, 100], [0, 1]);
  const backdropBlur = useTransform(scrollY, [0, 100], [0, 20]);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!mounted) return null;

  return (
    <>
      {/* Fixed navbar */}
      <motion.nav
        style={{
          backgroundColor: `rgba(20, 20, 20, ${opacity})`,
          backdropFilter: `blur(${backdropBlur}px)`,
        }}
        className="fixed left-0 right-0 top-0 z-50 border-b border-[#f4e7d3]/0"
      >
        <div className="flex items-center justify-between px-6 py-4 lg:px-16 lg:py-6">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center bg-[#ff6b2c]">
              <span className="font-[family-name:var(--font-space-grotesk)] text-sm font-bold text-[#141414]">
                E
              </span>
            </div>
            <span className="hidden font-[family-name:var(--font-space-grotesk)] text-sm font-bold uppercase tracking-tight text-[#f4e7d3] sm:block">
              EDGEFORGE
            </span>
          </a>

          {/* Desktop nav */}
          <div className="hidden items-center gap-8 lg:flex">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="group relative font-mono text-xs uppercase tracking-widest text-[#f4e7d3]/70 transition-colors hover:text-[#f4e7d3]"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-[#ff6b2c] transition-all group-hover:w-full" />
              </a>
            ))}
            <a
              href="#contact"
              className="border border-[#ff6b2c] px-4 py-2 font-mono text-xs uppercase tracking-widest text-[#ff6b2c] transition-all hover:bg-[#ff6b2c] hover:text-[#141414]"
            >
              Start Project
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="relative z-50 flex h-10 w-10 flex-col items-center justify-center gap-1.5 lg:hidden"
            aria-label="Toggle menu"
          >
            <motion.span
              animate={{
                rotate: isOpen ? 45 : 0,
                y: isOpen ? 6 : 0,
              }}
              className="h-px w-6 bg-[#f4e7d3]"
            />
            <motion.span
              animate={{
                opacity: isOpen ? 0 : 1,
              }}
              className="h-px w-6 bg-[#f4e7d3]"
            />
            <motion.span
              animate={{
                rotate: isOpen ? -45 : 0,
                y: isOpen ? -6 : 0,
              }}
              className="h-px w-6 bg-[#f4e7d3]"
            />
          </button>
        </div>
      </motion.nav>

      {/* Mobile menu overlay */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? "auto" : "none",
        }}
        transition={{ duration: 0.3 }}
        className="fixed inset-0 z-40 bg-[#141414]/95 backdrop-blur-xl lg:hidden"
      >
        <div className="flex h-full flex-col items-center justify-center gap-8">
          {navLinks.map((link, index) => (
            <motion.a
              key={link.name}
              href={link.href}
              onClick={() => setIsOpen(false)}
              initial={{ opacity: 0, y: 20 }}
              animate={isOpen ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ delay: index * 0.1 }}
              className="font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase tracking-tight text-[#f4e7d3] transition-colors hover:text-[#ff6b2c]"
            >
              {link.name}
            </motion.a>
          ))}
          <motion.a
            href="#contact"
            onClick={() => setIsOpen(false)}
            initial={{ opacity: 0, y: 20 }}
            animate={
              isOpen
                ? { opacity: 1, y: 0 }
                : { opacity: 0, y: 20 }
            }
            transition={{ delay: 0.4 }}
            className="mt-4 border border-[#ff6b2c] px-8 py-3 font-mono text-sm uppercase tracking-widest text-[#ff6b2c] transition-all hover:bg-[#ff6b2c] hover:text-[#141414]"
          >
            Start Project
          </motion.a>
        </div>
      </motion.div>
    </>
  );
}
