"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const floatingKeywords = [
  { text: "SECURITY", delay: 0 },
  { text: "EDGE", delay: 0.2 },
  { text: "AI", delay: 0.4 },
  { text: "CLOUD", delay: 0.6 },
];

function GradientMesh() {
  return (
    <div className="absolute right-0 top-0 h-full w-full overflow-hidden lg:w-1/2">
      <svg
        className="mesh-animate h-full w-full opacity-60"
        viewBox="0 0 600 600"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient
            id="mesh1"
            cx="0.3"
            cy="0.3"
            r="0.7"
            gradientUnits="objectBoundingBox"
          >
            <stop offset="0%" stopColor="#ff6b2c" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#ff6b2c" stopOpacity="0" />
          </radialGradient>
          <radialGradient
            id="mesh2"
            cx="0.7"
            cy="0.6"
            r="0.6"
            gradientUnits="objectBoundingBox"
          >
            <stop offset="0%" stopColor="#5eead4" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#5eead4" stopOpacity="0" />
          </radialGradient>
          <radialGradient
            id="mesh3"
            cx="0.5"
            cy="0.8"
            r="0.5"
            gradientUnits="objectBoundingBox"
          >
            <stop offset="0%" stopColor="#f4e7d3" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#f4e7d3" stopOpacity="0" />
          </radialGradient>
          <filter id="blur" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="40" />
          </filter>
        </defs>
        <g filter="url(#blur)">
          <motion.circle
            cx="200"
            cy="200"
            r="200"
            fill="url(#mesh1)"
            animate={{
              cx: [200, 250, 180, 200],
              cy: [200, 180, 250, 200],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.circle
            cx="400"
            cy="350"
            r="180"
            fill="url(#mesh2)"
            animate={{
              cx: [400, 350, 420, 400],
              cy: [350, 400, 320, 350],
            }}
            transition={{
              duration: 18,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.circle
            cx="300"
            cy="480"
            r="150"
            fill="url(#mesh3)"
            animate={{
              cx: [300, 350, 280, 300],
              cy: [480, 450, 500, 480],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </g>
      </svg>
    </div>
  );
}

function FloatingCard({
  text,
  delay,
  index,
}: {
  text: string;
  delay: number;
  index: number;
}) {
  const positions = [
    { right: "15%", top: "20%" },
    { right: "8%", top: "40%" },
    { right: "20%", top: "60%" },
    { right: "5%", top: "75%" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: delay + 0.8, duration: 0.6 }}
      className="glass-card absolute hidden rounded-sm px-4 py-2 lg:block"
      style={positions[index]}
    >
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{
          duration: 3 + index * 0.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <span className="font-mono text-xs tracking-widest text-[#5eead4]">
          {text}
        </span>
      </motion.div>
    </motion.div>
  );
}

export function Hero() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <section className="relative min-h-screen overflow-hidden bg-[#141414]">
      {/* Gradient Mesh */}
      <GradientMesh />

      {/* Floating keyword cards */}
      {floatingKeywords.map((keyword, index) => (
        <FloatingCard
          key={keyword.text}
          text={keyword.text}
          delay={keyword.delay}
          index={index}
        />
      ))}

      {/* Vertical divider line */}
      <div className="absolute bottom-0 left-8 top-0 hidden w-px bg-gradient-to-b from-transparent via-[#f4e7d3]/20 to-transparent lg:block" />

      {/* Content */}
      <div className="relative z-10 flex min-h-screen flex-col justify-center px-6 pb-20 pt-32 lg:px-16">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-[#ff6b2c]">
            Digital Security Studio
          </span>
        </motion.div>

        {/* Large kinetic headline - partially clipped */}
        <div className="overflow-visible">
          <motion.h1
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="-ml-1 max-w-5xl text-balance font-[family-name:var(--font-space-grotesk)] text-5xl font-bold uppercase leading-[0.9] tracking-tight text-[#f4e7d3] sm:text-7xl lg:-ml-2 lg:text-8xl xl:text-9xl"
          >
            Engineering
            <br />
            <span className="text-glow-orange text-[#ff6b2c]">Security</span>
            <br />
            at the Edge.
          </motion.h1>
        </div>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8 max-w-md text-base leading-relaxed text-[#f4e7d3]/70 lg:mt-12 lg:text-lg"
        >
          We forge digital fortresses and intelligent systems for the modern
          era. Uncompromising security meets cutting-edge innovation.
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-10 flex flex-wrap gap-4 lg:mt-14"
        >
          <a
            href="#work"
            className="glow-orange group inline-flex items-center gap-2 bg-[#ff6b2c] px-6 py-3 font-mono text-sm uppercase tracking-wider text-[#141414] transition-all hover:bg-[#ff8c5a]"
          >
            View Work
            <svg
              className="h-4 w-4 transition-transform group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 border border-[#f4e7d3]/20 px-6 py-3 font-mono text-sm uppercase tracking-wider text-[#f4e7d3] transition-all hover:border-[#f4e7d3]/40 hover:bg-[#f4e7d3]/5"
          >
            Start Project
          </a>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-6 lg:left-16"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="flex flex-col items-center gap-2"
          >
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/50">
              Scroll
            </span>
            <div className="h-12 w-px bg-gradient-to-b from-[#ff6b2c] to-transparent" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
