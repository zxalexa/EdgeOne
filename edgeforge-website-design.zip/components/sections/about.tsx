"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

export function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="relative bg-[#141414] py-24 lg:py-40">
      {/* Section divider */}
      <div className="section-divider absolute left-0 right-0 top-0" />

      <div className="px-6 lg:px-16">
        <div
          ref={ref}
          className="grid items-start gap-8 lg:grid-cols-12 lg:gap-16"
        >
          {/* Left - Oversized number */}
          <div className="lg:col-span-4">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <span className="font-[family-name:var(--font-space-grotesk)] text-[12rem] font-bold leading-none text-[#f4e7d3]/5 sm:text-[16rem] lg:text-[20rem]">
                01
              </span>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="absolute left-2 top-8 font-mono text-xs uppercase tracking-[0.2em] text-[#ff6b2c] lg:left-4 lg:top-12"
              >
                About Us
              </motion.span>
            </motion.div>
          </div>

          {/* Right - Content */}
          <div className="-mt-24 lg:col-span-7 lg:col-start-6 lg:mt-24">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="max-w-xl"
            >
              <h2 className="mb-8 font-[family-name:var(--font-space-grotesk)] text-3xl font-bold uppercase leading-tight text-[#f4e7d3] lg:text-4xl">
                We Build at the
                <span className="text-[#5eead4]"> Intersection</span> of
                Security & Innovation
              </h2>

              <div className="space-y-6 text-base leading-relaxed text-[#f4e7d3]/70 lg:text-lg">
                <p>
                  EDGEFORGE is a specialized digital studio focused on creating
                  secure, intelligent systems for forward-thinking
                  organizations. We operate at the bleeding edge of technology,
                  where security meets scalability.
                </p>
                <p>
                  Our team combines deep expertise in cryptographic systems,
                  distributed architecture, and machine learning to deliver
                  solutions that are both robust and revolutionary.
                </p>
              </div>

              {/* Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="mt-12 grid grid-cols-3 gap-8"
              >
                {[
                  { number: "50+", label: "Projects Secured" },
                  { number: "99.9%", label: "Uptime Guarantee" },
                  { number: "24/7", label: "Threat Monitoring" },
                ].map((stat, index) => (
                  <div key={stat.label} className="text-center lg:text-left">
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={isInView ? { opacity: 1 } : {}}
                      transition={{ duration: 0.4, delay: 0.8 + index * 0.1 }}
                      className="block font-[family-name:var(--font-space-grotesk)] text-2xl font-bold text-[#ff6b2c] lg:text-3xl"
                    >
                      {stat.number}
                    </motion.span>
                    <span className="mt-1 block font-mono text-[10px] uppercase tracking-widest text-[#f4e7d3]/50 lg:text-xs">
                      {stat.label}
                    </span>
                  </div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Vertical accent line */}
      <div className="absolute bottom-0 right-24 top-0 hidden w-px bg-gradient-to-b from-transparent via-[#5eead4]/20 to-transparent lg:block" />
    </section>
  );
}
